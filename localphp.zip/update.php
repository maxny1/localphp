<?php
$_GET['server'];












?>
