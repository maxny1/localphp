<?php
echo phpinfo();

?>
